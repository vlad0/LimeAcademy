import { Component } from '@angular/core';
import * as IPFS from 'ipfs-api';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'ipfs-test';

  constructor() {
    console.log('IPFS: ', IPFS);
  }
}
